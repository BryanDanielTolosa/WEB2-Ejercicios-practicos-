<?php

# Esto es una variable numerica

$numeroCinco = 5;

echo "Esto es una variable numero: $numeroCinco";
echo "<br><br>";

# Variable Texto

$palabra = "palabra";

echo "Esto es una varible Texto: $palabra";
echo "<br><br>";

# Varible boolean
# si la variable es false no muestra nada, en php
$voleana = true;

echo "Esto es una varible Boolean: $voleana";
echo "<br><br>";

# Variable Arreglo

$colores = array("Rojo", "Azul", "Amarillo", "Verde");

echo "Esto es una varible Arreglo: $colores[1]";
echo "<br><br>";

# Variable Arreglo con propiedades

$verduras = array("verdura1"=>"Leche", "verdura2"=>"Cebolla");

echo "Esto es una varible Arreglo con propiedades: $verduras[verdura1]";
echo "<br><br>";

# Varible tipo objeto

$frutas = (object)["fruta1"=>"Banana","fruta2"=>"Frutilla"];

echo "Esto es una variable objeto: $frutas->fruta1";

?>