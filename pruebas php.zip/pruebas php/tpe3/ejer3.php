/* 

Cree una base de datos para registrar pagos de deudas. Directamente desde PhpMyAdmin o cualquier cliente gráfico, sin usar PHP.
Cree la tabla pagos con la siguiente información
deudor: Nombre de la persona
cuota : Número de cuota pagada
cuota_capital: Monto  de la cuota pagada
fecha_pago: Fecha que se realizó el pago de la cuota

¿Es necesario agregar una clave primaria?

Inserte varios registros “a mano”.
Realize consultas SQL para:
Listar todos los pagos
Listar sólo aquellos pagos que pertenezcan a un deudor determinado
Listar los pagos mayores a un monto determinado
Eliminar un pago determinado.
Insertar un pago
Actualizar la cuota_capital de un pago determinado


Paso 1: Crear la base de datos y la tabla
Crear la base de datos:

En PhpMyAdmin, selecciona "Base de datos" y crea una nueva base de datos, por ejemplo, deudas_db.
Crear la tabla pagos:

Selecciona la base de datos deudas_db.
Haz clic en "SQL" y ejecuta el siguiente código:
sql
Copiar código
CREATE TABLE pagos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deudor VARCHAR(100) NOT NULL,
    cuota INT NOT NULL,
    cuota_capital DECIMAL(10, 2) NOT NULL,
    fecha_pago DATE NOT NULL
);
Aquí, id es la clave primaria, que es recomendable agregar para identificar cada registro de forma única.

Paso 2: Insertar registros manualmente
Puedes insertar registros usando el formulario de PhpMyAdmin o con la siguiente consulta SQL:

sql

INSERT INTO pagos (deudor, cuota, cuota_capital, fecha_pago) VALUES
('Juan Pérez', 1, 500.00, '2024-01-15'),
('María López', 2, 300.00, '2024-01-20'),
('Juan Pérez', 2, 500.00, '2024-02-15');
Paso 3: Realizar consultas SQL
Listar todos los pagos:

sql

SELECT * FROM pagos;
Listar pagos de un deudor determinado (ejemplo: Juan Pérez):

sql

SELECT * FROM pagos WHERE deudor = 'Juan Pérez';
Listar pagos mayores a un monto determinado (ejemplo: mayores a 400.00):

sql

SELECT * FROM pagos WHERE cuota_capital > 400.00;
Eliminar un pago determinado (ejemplo: pago con id = 1):

sql

DELETE FROM pagos WHERE id = 1;
Insertar un pago:

sql

INSERT INTO pagos (deudor, cuota, cuota_capital, fecha_pago) VALUES ('Carlos Ruiz', 1, 450.00, '2024-03-10');
Actualizar la cuota_capital de un pago determinado (ejemplo: actualizar cuota_capital de id = 2):

sql

UPDATE pagos SET cuota_capital = 600.00 WHERE id = 2;
*/