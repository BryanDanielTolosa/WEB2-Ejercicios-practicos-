<?php
$dsn = 'mysql:host=localhost;dbname=pagos';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $message = '';

    // Consulta para listar todos los registros
    $stmt = $pdo->query('SELECT * FROM pagos');
    $pagos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $deudor = $_POST['deudor'];
        $cuota = $_POST['cuota'];
        $cuota_capital = $_POST['cuota_capital'];
        $fecha_pago = $_POST['fecha_pago'];

        $stmt = $pdo->prepare('SELECT * FROM pagos WHERE deudor = ? AND cuota = ? AND fecha_pago = ?');
        $stmt->execute([$deudor, $cuota, $fecha_pago]);
        $existing_payment = $stmt->fetch();

        if ($existing_payment) {
            $message = "Este pago ya ha sido registrado.";
        } else {
            $stmt = $pdo->prepare('INSERT INTO pagos (deudor, cuota, cuota_capital, fecha_pago) VALUES (?, ?, ?, ?)');
            $stmt->execute([$deudor, $cuota, $cuota_capital, $fecha_pago]);
            $message = "Pago registrado exitosamente.";
        }

        $stmt = $pdo->query('SELECT * FROM pagos');
        $pagos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Pagos</title>
</head>
<body>
    <h1>Lista de Pagos</h1>
    <?php if ($message): ?>
        <p><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Deudor</th>
            <th>Cuota</th>
            <th>Cuota Capital</th>
            <th>Fecha de Pago</th>
        </tr>
        <?php foreach ($pagos as $pago): ?>
        <tr>
            <td><?php echo isset($pago['id']) ? $pago['id'] : 'Sin ID'; ?></td>
            <td><?php echo htmlspecialchars($pago['deudor']); ?></td>
            <td><?php echo $pago['cuota']; ?></td>
            <td><?php echo $pago['cuota_capital']; ?></td>
            <td><?php echo $pago['fecha_pago']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h1>Agregar Pago</h1>
    <form action="" method="POST">
        <label for="deudor">Deudor:</label>
        <input type="text" name="deudor" required><br>
        
        <label for="cuota">Cuota:</label>
        <input type="number" name="cuota" required><br>
        
        <label for="cuota_capital">Cuota Capital:</label>
        <input type="number" step="0.01" name="cuota_capital" required><br>
        
        <label for="fecha_pago">Fecha de Pago:</label>
        <input type="date" name="fecha_pago" required><br>
        
        <input type="submit" value="Agregar Pago">
    </form>
</body>
</html>