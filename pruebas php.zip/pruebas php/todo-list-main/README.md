# TODOList App
Lista de tareas utilizando renderización del lado del servidor con PHP y MySQL.

## Importar la DB
Importar el archivo `db_tareas.sql` dentro de PHPMyAdmin para tener la base de datos completa.